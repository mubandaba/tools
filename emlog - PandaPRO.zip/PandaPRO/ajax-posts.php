<?php
include "../../../init.php";

/**
 * 获取文章列表
 */
function article ($params) {
    $options = getOptions();
    // 接收参数
    $sid     = isset($params['sid']) ? intval(trim($params['sid'])) : 0;
    $page    = isset($params['page']) ? intval(trim($params['page'])) : 1;
    $perpage = isset($params['perpage']) ? intval(trim($params['perpage'])) : $options['index_lognum'];
    $top     = isset($params['top']) ? intval(trim($params['top'])) : 0;

    // 判断参数
    $map = '';

    if ($sid) {
        $map = ' and sortid = ' . $sid;
    }
    if ($top) {
        $map = ' and (sortop = "y" or top = "y")';
    }

    // 获取数据
    global $CACHE;
    $sort_cache = $CACHE->readCache('sort');
    $author_cache = $CACHE->readCache('user');
    $logModel = new Log_Model();
    
    $logs = $logModel->getLogsForHome($map . " order by top desc, sortop desc, gid desc", $page, $perpage);

    $data = array();

    foreach ($logs as $key => $value) {
        $imgs = getFirstAtt($value['gid']);
        if (!$imgs) {
            $imgs = getImgFromDesc($value['content']);
        }
        if (count($imgs) > 3) {
            $imgs = array_slice($imgs, 0, 3);
        }
        $data[] = array(
            'gid' => $value['gid'], // 文章id
            'title' => $value['title'], // 文章标题
            'date' => smartDate($value['date']), // 发布时间，unix时间戳
//            'excerpt' => str_replace('阅读全文&gt;&gt;', '', $value['log_description']),
            'author' => $value['author'],
            'nickname' => $author_cache[$value['author']]['name'],
            'sortid' => $value['sortid'], // 分类id
            'sortname' => $sort_cache[$value['sortid']]['sortname'], // 分类名称
            'views' => $value['views'], // 浏览数
            'comnum' => $value['comnum'], // 评论数
            'top' => $value['top'],
            'sortop' => $value['sortop'],
            'imgs' => $imgs
        );
    }
    ajaxReturn(1, '获取文章列表成功', $data);
}