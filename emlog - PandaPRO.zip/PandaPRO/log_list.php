<?php 
/**
 * 站点首页模板
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<main class="py-3  py-md-5 ">
<div class="container">
	<?php if($sortName):?>
	<div class="d-none d-md-block breadcrumbs text-muted mb-2">
	  <span itemprop="itemListElement">
	    <a href="<?php echo BLOG_URL;?>" itemprop="item" class="home">
	      <span itemprop="name">网站首页</span></a>
	  </span>
	  <span class="sep">›</span>
	  <span class="current"><?php echo $sortName;?></span>
	</div>
	<?php endif;?>
	<div class="row">
	<div class="col-lg-8">
		<?php if($pageurl == Url::logPage()){?>
		<div class="list-banner list-rounded banner-style-3 banner-has-nav mb-4 mb-md-4">
		  <div class="owl-carousel owl-theme">
		    <div class="card item list-item list-overlay-content m-0">
		      <div class="media media-2x1">
		        <a class="media-content" target="_blank" href="https://apollo.1.demo.nicetheme.xyz/news/4809" style='background-image:url("data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")' data-bg=" url(https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/06/2019062004480810.jpg)" data-nclazyload="true">
		          <span class="overlay"></span>
		        </a>
		      </div>
		      <div class="list-content text-center text-md-left p-3 p-md-4">
		        <div class="list-body">
		          <a href="https://apollo.1.demo.nicetheme.xyz/news/4809" target="_blank" class="h4 text-white h-2x m-0">路透：阿里巴巴、京东计划向商户推出数据服务</a></div>
		      </div>
		    </div>
		    <div class="card item list-item list-overlay-content m-0">
		      <div class="media media-2x1">
		        <a class="media-content" target="_blank" href="https://apollo.1.demo.nicetheme.xyz/4625" style='background-image:url("data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7")' data-bg=" url(https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/06/2019062004540484.jpg)" data-nclazyload="true">
		          <span class="overlay"></span>
		        </a>
		      </div>
		      <div class="list-content text-center text-md-left p-3 p-md-4">
		        <div class="list-body">
		          <a href="https://apollo.1.demo.nicetheme.xyz/4625" target="_blank" class="h4 text-white h-2x m-0">5 年估值 80 亿美金，寻找中国版 Peloton | 36氪新风向</a></div>
		      </div>
		    </div>
		  </div>
		</div>
		<?php }elseif($sortName){?>
		<div class="list-cover list-rounded mb-3 mb-md-4">
		  <div class="list-item list-overlay-content overlay-hover bg-dark">
		    <div class="media media-21x9">
		      <div class="media-content" style="background-image: url(&quot;https://pandapro.demo.nicetheme.xyz/wp-content/themes/PandaPRO-1.0.4/images/default-cover.jpg&quot;);" data-bg="url('https://pandapro.demo.nicetheme.xyz/wp-content/themes/PandaPRO-1.0.4/images/default-cover.jpg')" data-nclazyload="true" data-was-processed="true">
		        <div class="overlay"></div>
		      </div>
		    </div>
		    <div class="list-content p-3 p-md-4">
		      <div class="list-body">
		        <div class="d-flex align-items-center">
		          <div class="text-xl"><?php echo $sortName;?></div>
		          <div class="flex-fill"></div>
		          <div class="text-light">
		            <i class="text-xl iconfont icon-file-text-line mr-1"></i>
		            <span class="text-xs "><?php echo $lognum;?> 篇文章</span></div>
		        </div>
		        <div class="border-top border-white mt-2 mt-md-3 pt-2 pt-md-3">
		          <div class="text-sm h-2x"><?php echo ($sort['description'])?$sort['description']:'该分类暂时没有描述！'?></div>
		          <div class="border-theme bg-primary"></div>
		        </div>
		      </div>
		    </div>
		  </div>
		</div>
		<?php }?>
		<div class="list-home list-grid list-grid-padding">

		<?php doAction('index_loglist_top'); ?>

		<?php 
		if (!empty($logs)):
		foreach($logs as $value): 
		?>
		<?php if(img_count($value['content']) >=1 && img_count($value['content']) < 3){?>
		  <div class="list-item block card-plain ">
		    <div class="media media-3x2 col-4 col-md-4">
		      <a class="media-content" href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" style="background-image: url(&quot;<?php thumbnail($value);?>&quot;);" data-bg="url('<?php thumbnail($value);?>')" data-nclazyload="true" data-was-processed="true"></a>
		    </div>
		    <div class="list-content">
		      <div class="list-body">
		        <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" class="list-title text-lg h-2x">
		          <?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><?php echo $value['log_title']; ?></a>
		        <div class="list-desc d-none d-md-block text-sm text-secondary my-3">
		          <div class="h-2x "><?php echo subString(strip_tags($value['log_description']),0,100);?></div></div>
		      </div>
		      <div class="list-footer">
		        <div class="d-flex flex-fill align-items-center text-muted text-xs">
		          <?php blog_author($value['author']); ?>
		          <div class="d-inline-block mx-1 mx-md-2">
		            <i class="text-primary">—</i></div>
		          <div class="d-inline-block"><?php blog_sort($value['logid']); ?></div>
		          <div class="flex-fill"></div>
		          <div>
		            <time class="mx-1"><?php echo timeago(gmdate('Y-m-d G:i:s', $value['date'])); ?></time></div>
		        </div>
		      </div>
		    </div>
		  </div>

		<?php }elseif(img_count($value['content']) >= 3){?>
		
		  <div class="list-item list-item-column block">
		    <div class="list-content p-0">
		      <div class="list-body ">
		        <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" target="_blank" class="list-title text-lg h-2x mb-2 mb-md-3">
		          <?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><?php echo $value['log_title']; ?></a>
		        <div class="mb-2 mb-md-3">
		          <div class="d-flex flex-fill align-items-center text-muted text-xs">
		            <?php blog_author($value['author']); ?>
		            <div class="d-inline-block mx-1 mx-md-2">
		              <i class="text-primary">—</i></div>
		            <div class="d-inline-block"><?php blog_sort($value['logid']); ?></div>
		            <div class="flex-fill"></div>
		            <div>
		              <time class="mx-1"><?php echo timeago(gmdate('Y-m-d G:i:s', $value['date'])); ?></time></div>
		          </div>
		        </div>
		      </div>
		      <div class="row-xs mb-md-3">
		      	<?php 
	        	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
	        	for($i=0;$i<3;$i++){
	        	?>
		        <div class="col-4">
		          <div class="media media-3x2">
		            <a class="media-content" title="<?php echo $value['log_title']; ?>" href="<?php echo $value['log_url']; ?>" target="_blank" style="background-image: url(&quot;<?php echo $img[1][$i];?>&quot;);" data-bg=" url('<?php echo $img[1][$i];?>')" data-nclazyload="true" data-was-processed="true"></a>
		          </div>
		        </div>
				<?php }?>
		      </div>
		      <div class="list-desc d-none d-md-block text-sm text-secondary">
		        <div class="h-2x"><?php echo subString(strip_tags($value['log_description']),0,120);?></div></div>
		    </div>
		  </div>

		<?php }elseif(img_count($value['content']) == 0){?>

		  <div class="list-item block ">
		    <div class="list-content p-0">
		      <div class="list-body">
		        <a href="<?php echo $value['log_url']; ?>" title="<?php echo $value['log_title']; ?>" class="list-title text-lg h-2x"><?php topflg($value['top'], $value['sortop'], isset($sortid)?$sortid:''); ?><?php echo $value['log_title']; ?></a>
		        <div class="list-meta mt-2 mt-md-3">
		          <div class="d-flex flex-fill align-items-center text-muted text-xs">
		            <?php blog_author($value['author']); ?>
		            <div class="d-inline-block mx-1 mx-md-2">
		              <i class="text-primary">—</i></div>
		            <div class="d-inline-block"><?php blog_sort($value['logid']); ?></div>
		            <div class="flex-fill"></div>
		            <div>
		              <time class="mx-1"><?php echo timeago(gmdate('Y-m-d G:i:s', $value['date'])); ?></time></div>
		          </div>
		        </div>
		        <div class="list-desc text-sm text-secondary mt-2 mt-md-3">
		          <div class="h-2x "><?php echo subString(strip_tags($value['log_description']),0,200);?></div></div>
		      </div>
		    </div>
		  </div>
		  <?php }?>
		  <?php 
			endforeach;
			else:
			?>
			<h2>未找到</h2>
			<p>抱歉，没有符合您查询条件的结果。</p>
		<?php endif;?>
		</div>

		<?php echo list_page($lognum,$index_lognum,$page,$pageurl);?>

		<section class="list-sales mt-4 d-none d-lg-block"><a href="https://www.nicetheme.cn/store/pandapro" target="_blank"><img src="https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/07/2019072006470679.png" data-src="https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/07/2019072006470679.png" data-nclazyload="true" class="loaded" data-was-processed="true"></a>
            </section>

        <section class="list-sales mt-4 d-lg-none"><a href="https://www.nicetheme.cn/store/pandapro" target="_blank"><img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/07/2019072006482096.png" data-nclazyload="true"></a>
            </section>
    </div>

<?php
 include View::getView('side');
 include View::getView('footer');
?>