<?php 
/* Template Name:PandaPRO
Description:PandaPRO
Version:1.2 Author:MENGX
Author Url:https://mengx.io
Sidebar Amount:1 */
if(!defined( 'EMLOG_ROOT')) {exit( 'error!');} 
require_once View::getView( 'module');
start();
?>
  <!DOCTYPE html>
  <html lang="zh-CN">
    
    <head>
      <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
      <title>
        <?php echo $site_title; ?></title>
      <meta name="keywords" content="<?php echo $site_key; ?>" />
      <meta name="description" content="<?php echo $site_description; ?>" />
      <link rel="EditURI" type="application/rsd+xml" title="RSD" href="<?php echo BLOG_URL; ?>xmlrpc.php?rsd" />
      <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="<?php echo BLOG_URL; ?>wlwmanifest.xml" />
      <link rel="alternate" type="application/rss+xml" title="RSS" href="<?php echo BLOG_URL; ?>rss.php" />
      <link rel="stylesheet" id="jimu-css-css" href="https://apollo.1.demo.nicetheme.xyz/wp-content/plugins/nicetheme-jimu/modules/jimu.css?ver=1.0" type="text/css" media="all">
      <link rel="stylesheet" id="ncLightgalleryCss-css" href="https://apollo.1.demo.nicetheme.xyz/wp-content/plugins/nicetheme-jimu/modules/base/assets/lightGallery/css/lightgallery.min.css?ver=1.0" type="text/css" media="all">
      <link rel="stylesheet" id="nicetheme-iconfont-css" href="<?php echo TEMPLATE_URL; ?>fonts/iconfont.css?ver=5.2.5" type="text/css" media="all">
      <link rel="stylesheet" id="nicetheme-nicetheme-css" href="<?php echo TEMPLATE_URL; ?>css/nicetheme.css?ver=5.2.5" type="text/css" media="all">
      <link rel="stylesheet" id="nicetheme-style-css" href="<?php echo TEMPLATE_URL; ?>style.css?ver=5.2.5" type="text/css" media="all">
      <script type="text/javascript">/* <![CDATA[ */
        var globals = {
          "ajax_url": "<?php echo TEMPLATE_URL; ?>api.php",
          "url_theme": "<?php echo TEMPLATE_URL; ?>",
          "site_url": "<?php echo BLOG_URL;?>",
          "post_id": "<?php echo $logid;?>"
        };
        var __ = {
          "load_more": "\u52a0\u8f7d\u66f4\u591a",
          "reached_the_end": "- \u6ca1\u6709\u66f4\u591a\u5185\u5bb9 -",
          "thank_you": "\u8c22\u8c22\u70b9\u8d5e",
          "success": "\u64cd\u4f5c\u6210\u529f",
          "cancelled": "\u53d6\u6d88\u70b9\u8d5e"
        };
        var contribute = {
          "markdown": "1",
          "image_resize": "1",
          "image_drop": "1",
          "magic_url": "1",
          "emoji": "1",
          "__": {
            "unsaved": "\u4ecd\u6709\u5185\u5bb9\u672a\u4fdd\u5b58\uff0c\u60a8\u786e\u5b9a\u8981\u5173\u95ed\u5417\uff1f",
            "title_empty": "\u6587\u7ae0\u6807\u9898\u4e0d\u80fd\u4e3a\u7a7a\uff01",
            "content_empty": "\u6587\u7ae0\u5185\u5bb9\u4e0d\u80fd\u4e3a\u7a7a\uff01",
            "invalid_email": "\u8bf7\u586b\u5199\u6b63\u786e\u7684\u90ae\u7bb1",
            "word_count": "\u603b\u5b57\u6570\uff1a",
            "max_size": "\u4ec5\u5141\u8bb8\u4e0a\u4f20\u56fe\u7247\u6587\u4ef6\u4e14\u5927\u5c0f\u4e0d\u8d85\u8fc7 2M\uff01",
            "type_something": "\u6211\u8981\u5199\u70b9\u4ec0\u4e48\u2026",
            "submit": "\u63d0\u4ea4\u7a3f\u4ef6",
            "draft": "\u4fdd\u5b58\u8349\u7a3f",
            "one_cat": "\u81f3\u5c11\u9009\u62e9\u4e00\u4e2a\u5206\u7c7b\uff01",
            "three_cat": "\u6700\u591a\u9009\u62e9\u4e09\u4e2a\u5206\u7c7b\uff01",
            "required": "\u8bf7\u586b\u5199\u5b8c\u6574\u7248\u6743\u8bf4\u660e"
          }
        };
        /* ]]> */
        </script>
      <script type="text/javascript" src="https://apollo.1.demo.nicetheme.xyz/wp-includes/js/jquery/jquery.js?ver=1.12.4-wp"></script>
      <script type="text/javascript" src="https://apollo.1.demo.nicetheme.xyz/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1"></script>
      <link rel="icon" href="https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/07/cropped-2019072007315247-32x32.jpg" sizes="32x32">
      <link rel="icon" href="https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/07/cropped-2019072007315247-192x192.jpg" sizes="192x192">
      <link rel="apple-touch-icon-precomposed" href="https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/07/cropped-2019072007315247-180x180.jpg">
      <meta name="msapplication-TileImage" content="https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/07/cropped-2019072007315247-270x270.jpg">
      <?php doAction( 'index_head'); ?></head>
    
    <body class="home blog <?php if($_COOKIE['Apollo_dark_mode'] == 'on'){echo 'nice-dark-mode';}?>">
      <header class="header">
        <meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
        <nav class="navbar navbar-expand-lg shadow">
          <div class="container">
            <!-- / brand -->
            <a href="<?php echo BLOG_URL;?>" rel="home" class="logo navbar-brand order-2 order-lg-1">
              <img src="https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/11/2019110410182756.png" class="<?php if($_COOKIE['Apollo_dark_mode'] == 'on'){echo 'd-none';}else{echo'd-inline-block';}?> logo-light nc-no-lazy" alt="<?php echo $blogname;?>">
              <img src="https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/11/2019110410182593.png" class="<?php if($_COOKIE['Apollo_dark_mode'] == 'on'){echo 'd-inline-block';}else{echo'd-none';}?> logo-dark nc-no-lazy" alt="<?php echo $blogname;?>"></a>
            <button class="navbar-toggler order-1" type="button" id="sidebarCollapse">
              <i class="text-xl iconfont icon-menu-line"></i>
            </button>
            <button class="navbar-toggler nav-search order-3 collapsed" data-target="#navbar-search" data-toggle="collapse" aria-expanded="false" aria-controls="navbar-search">
              <i class="text-xl iconfont icon-search-line"></i>
              <i class="text-xl iconfont icon-close-fill"></i>
            </button>
            <!-- brand -->
            <div class="collapse navbar-collapse order-md-2">
              <?php blog_navi();?>
                <ul class="navbar-nav align-items-center order-1 order-lg-2">
                  <li class="nav-item">
                    <a class="btn btn-link btn-icon nav-switch-dark-mode" href="javascript:">
                      <span class=" icon-light-mode" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="夜晚模式">
                        <i class="text-lg iconfont icon-moon-line"></i>
                      </span>
                      <span class="icon-dark-mode" data-toggle="tooltip" data-placement="bottom" title="" data-original-title="日间模式">
                        <i class="text-lg text-warning iconfont icon-moon-fill"></i>
                      </span>
                    </a>
                  </li>
                  <li class="nav-item ml-1 ml-md-2">
                    <a class="btn btn-link btn-icon nav-link nav-search collapsed" href="#navbar-search" data-toggle="collapse" title="Search" aria-expanded="false" aria-controls="navbar-search">
                      <span data-toggle="tooltip" data-placement="bottom" title="" data-original-title="搜索">
                        <i class="text-lg iconfont icon-search-line"></i>
                        <i class="text-lg iconfont icon-close-fill"></i>
                      </span>
                    </a>
                  </li>
                  
                  
                </ul>
            </div>
          </div>
        </nav>
        <div class="mobile-sidebar">
          <div class="mobile-sidebar-header">
            <div class="mobile-sidebar-author-cover">
              <div class="media media-2x1">
                <div class="media-content" style="background-image: url(&quot;https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/08/2019081314390589-e1565707155929.jpg&quot;);" data-bg="url('https://apollo.1.demo.nicetheme.xyz/wp-content/uploads/2019/08/2019081314390589-e1565707155929.jpg')" data-nclazyload="true" data-was-processed="true"></div>
                <div class="media-overlay overlay-top align-items-center p-3">
                  <div class="flex-fill"></div>
                  <div>
                    <button class="btn btn-icon nav-switch-dark-mode text-white mr-2">
                      <span class="icon-light-mode">
                        <i class="text-xl iconfont icon-moon-line "></i>
                      </span>
                      <span class="icon-dark-mode">
                        <i class="text-xl text-warning iconfont icon-moon-fill "></i>
                      </span>
                    </button>
                    <button class="btn btn-icon text-white sidebar-close">
                      <span>
                        <i class="text-xl iconfont icon-radio-button-line"></i>
                      </span>
                    </button>
                  </div>
                </div>
              </div>
            </div>

          </div>
          <?php mobile_navi();?>
        </div>
        <div class="navbar-search collapse " id="navbar-search" style="">
          <div class="container">
            <form method="get" role="search" id="searchform" class="searchform shadow" action="<?php echo BLOG_URL;?>index.php">
              <div class="input-group">
                <input type="text" name="keyword" id="s" placeholder="请输入搜索关键词并按回车键…" class="form-control" required="">
                <div class="input-group-append">
                  <button class="btn btn-nostyle" type="submit">
                    <i class="text-lg iconfont icon-search-line"></i>
                  </button>
                </div>
              </div>
              <!-- /input-group --></form>
          </div>
        </div>
      </header>