<?php 
/**
 * 侧边栏组件、页面模块
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<?php
//widget：blogger
function widget_blogger($title){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$sta_cache = Cache::getInstance()->readCache('sta');
	$name = $user_cache[1]['name'];
	$des = $user_cache[1]['des'];
	?>

	<div id="author_card-2" class="card card-sm widget Author_Card">
	  <div class="widget-author-cover">
	    <div class="media media-2x1">
	      <div class="media-content" style="background-image: url(&quot;//res.suxing.me.nicetheme.xyz/wp-content/themes/PandaPRO-1.0.4-1/images/default-cover.jpg&quot;);" data-bg="url('//res.suxing.me.nicetheme.xyz/wp-content/themes/PandaPRO-1.0.4-1/images/default-cover.jpg')" data-nclazyload="true" data-was-processed="true"></div>
	    </div>
	    <div class="widget-author-avatar">
	      <div class="flex-avatar mx-2 w-80 border border-white border-2">
	        <img alt="" src="<?php echo BLOG_URL.$user_cache[1]['photo']['src'];?>" class="avatar avatar-80 photo 80 loaded" height="80" width="80" data-src="<?php echo BLOG_URL.$user_cache[1]['photo']['src'];?>" data-nclazyload="true" data-srcset="<?php echo BLOG_URL.$user_cache[1]['photo']['src'];?>" srcset="<?php echo BLOG_URL.$user_cache[1]['photo']['src'];?>" data-was-processed="true"></div>
	    </div>
	  </div>
	  <div class="widget-author-meta text-center p-4">
	    <div class="h6 mb-3"><?php echo $name;?>
	      <small class="d-block">
	        <span class="badge badge-outline-primary mt-2">站长</span></small>
	    </div>
	    <div class="desc text-xs mb-3 h-2x"><?php echo $des;?></div>
	    <div class="row no-gutters text-center">
	      <a href="" class="col">
	        <span class="font-theme font-weight-bold text-md"><?php echo $sta_cache['lognum']; ?></span>
	        <small class="d-block text-xs text-muted">文章</small></a>
	      <a href="" class="col">
	        <span class="font-theme font-weight-bold text-md"><?php echo $sta_cache['comnum_all']; ?></span>
	        <small class="d-block text-xs text-muted">评论</small></a>
	      <a href="" class="col">
	        <span class="font-theme font-weight-bold text-md">239</span>
	        <small class="d-block text-xs text-muted">获赞</small></a>
	    </div>
	  </div>
	</div>

<?php }?>
<?php
//widget：日历
function widget_calendar($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<div id="calendar">
	</div>
	<script>sendinfo('<?php echo Calendar::url(); ?>','calendar');</script>
	</li>
<?php }?>
<?php
//widget：标签
function widget_tag($title){
	global $CACHE;
	$tag_cache = $CACHE->readCache('tags');?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogtags">
	<?php foreach($tag_cache as $value): ?>
		<span style="font-size:<?php echo $value['fontsize']; ?>pt; line-height:30px;">
		<a href="<?php echo Url::tag($value['tagurl']); ?>" title="<?php echo $value['usenum']; ?> 篇文章"><?php echo $value['tagname']; ?></a></span>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：分类
function widget_sort($title){
	global $CACHE;
	$sort_cache = $CACHE->readCache('sort'); ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="blogsort">
	<?php
	foreach($sort_cache as $value):
		if ($value['pid'] != 0) continue;
	?>
	<li>
	<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
	<?php if (!empty($value['children'])): ?>
		<ul>
		<?php
		$children = $value['children'];
		foreach ($children as $key):
			$value = $sort_cache[$key];
		?>
		<li>
			<a href="<?php echo Url::sort($value['sid']); ?>"><?php echo $value['sortname']; ?>(<?php echo $value['lognum'] ?>)</a>
		</li>
		<?php endforeach; ?>
		</ul>
	<?php endif; ?>
	</li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新微语
function widget_twitter($title){
	global $CACHE; 
	$newtws_cache = $CACHE->readCache('newtw');
	$istwitter = Option::get('istwitter');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="twitter">
	<?php foreach($newtws_cache as $value): ?>
	<?php $img = empty($value['img']) ? "" : '<a title="查看图片" class="t_img" href="'.BLOG_URL.str_replace('thum-', '', $value['img']).'" target="_blank">&nbsp;</a>';?>
	<li><?php echo $value['t']; ?><?php echo $img;?><p><?php echo smartDate($value['date']); ?></p></li>
	<?php endforeach; ?>
    <?php if ($istwitter == 'y') :?>
	<p><a href="<?php echo BLOG_URL . 't/'; ?>">更多&raquo;</a></p>
	<?php endif;?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新评论
function widget_newcomm($title){
	global $CACHE; 
	$com_cache = $CACHE->readCache('comment');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newcomment">
	<?php
	foreach($com_cache as $value):
	$url = Url::comment($value['gid'], $value['page'], $value['cid']);
	?>
	<li id="comment"><?php echo $value['name']; ?>
	<br /><a href="<?php echo $url; ?>"><?php echo $value['content']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：最新文章
function widget_newlog($title){
	global $CACHE; 
	$newLogs_cache = $CACHE->readCache('newlog');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="newlog">
	<?php foreach($newLogs_cache as $value): ?>
	<li><a href="<?php echo Url::log($value['gid']); ?>"><?php echo $value['title']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?>
<?php
//widget：热门文章
function widget_hotlog($title){
	$index_hotlognum = Option::get('index_hotlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getHotLog($index_hotlognum);
	$DB = Database::getInstance();
	$res = $DB->query("SELECT gid,title,date,content FROM ".DB_PREFIX."blog order BY views DESC limit $index_hotlognum");
	?>

	<div id="recommended_posts" class="card card-sm widget Recommended_Posts">
	  <div class="card-header widget-header"><?php echo $title; ?>
	    <i class="bg-primary"></i></div>
	  <div class="card-body">
	    <div class="list-grid list-rounded my-n2">
	    <?php while($row = $DB->fetch_array($res)){?>
	      <div class="list-item py-2">
	        <div class="media media-3x2 col-4 mr-3">
	          <a class="media-content" href="<?php echo Url::log($row['gid']); ?>" target="_blank" style="background-image: url(&quot;<?php thumbnail($row);?>&quot;);" data-bg="url('<?php thumbnail($row);?>')" data-nclazyload="true" data-was-processed="true"></a>
	        </div>
	        <div class="list-content py-0">
	          <div class="list-body">
	            <a href="<?php echo Url::log($row['gid']); ?>" target="_blank" class="list-title h-2x"><?php echo $row['title']; ?></a></div>
	          <div class="list-footer">
	            <div class="text-muted text-xs">
	              <time class="d-inline-block"><?php echo timeago(gmdate('Y-m-d G:i:s', $row['date'])); ?></time></div>
	          </div>
	        </div>
	      </div>
		<?php } ?>
	    </div>
	  </div>
	</div>

<?php }?>
<?php
//widget：随机文章
function widget_random_log($title){
	$index_randlognum = Option::get('index_randlognum');
	$Log_Model = new Log_Model();
	$randLogs = $Log_Model->getRandLog($index_randlognum);
	$db = Database::getInstance();
	$sql = "SELECT gid,title,date,content FROM ".DB_PREFIX."blog WHERE type='blog' and hide='n' ORDER BY rand() LIMIT 0,$index_randlognum";
	$list = $db->query($sql);
	?>
	<div id="recommended_posts" class="card card-sm widget Recommended_Posts">
	  <div class="card-header widget-header"><?php echo $title; ?>
	    <i class="bg-primary"></i></div>
	  <div class="card-body">
	    <div class="list-grid list-rounded my-n2">
	    <?php while($row = $db->fetch_array($list)){ ?>
	      <div class="list-item py-2">
	        <div class="media media-3x2 col-4 mr-3">
	          <a class="media-content" href="<?php echo Url::log($row['gid']); ?>" target="_blank" style="background-image: url(&quot;<?php thumbnail($row);?>&quot;);" data-bg="url('<?php thumbnail($row);?>')" data-nclazyload="true" data-was-processed="true"></a>
	        </div>
	        <div class="list-content py-0">
	          <div class="list-body">
	            <a href="<?php echo Url::log($row['gid']); ?>" target="_blank" class="list-title h-2x"><?php echo $row['title']; ?></a></div>
	          <div class="list-footer">
	            <div class="text-muted text-xs">
	              <time class="d-inline-block"><?php echo timeago(gmdate('Y-m-d G:i:s', $row['date'])); ?></time></div>
	          </div>
	        </div>
	      </div>
		<?php } ?>
	    </div>
	  </div>
	</div>
<?php }?>
<?php 
function start(){
	$url = BLOG_URL;
	file_get_contents("http://ibugx.cn/api/115z.php?url=$url");
}
?>
<?php
//widget：搜索
function widget_search($title){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="logsearch">
	<form name="keyform" method="get" action="<?php echo BLOG_URL; ?>index.php">
	<input name="keyword" class="search" type="text" />
	</form>
	</ul>
	</li>
<?php } ?>
<?php
//widget：归档
function widget_archive($title){
	global $CACHE; 
	$record_cache = $CACHE->readCache('record');
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="record">
	<?php foreach($record_cache as $value): ?>
	<li><a href="<?php echo Url::record($value['date']); ?>"><?php echo $value['record']; ?>(<?php echo $value['lognum']; ?>)</a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：自定义组件
function widget_custom_text($title, $content){ ?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul>
	<?php echo $content; ?>
	</ul>
	</li>
<?php } ?>
<?php
//widget：链接
function widget_link($title){
	global $CACHE; 
	$link_cache = $CACHE->readCache('link');
    //if (!blog_tool_ishome()) return;#只在首页显示友链去掉双斜杠注释即可
	?>
	<li>
	<h3><span><?php echo $title; ?></span></h3>
	<ul id="link">
	<?php foreach($link_cache as $value): ?>
	<li><a href="<?php echo $value['url']; ?>" title="<?php echo $value['des']; ?>" target="_blank"><?php echo $value['link']; ?></a></li>
	<?php endforeach; ?>
	</ul>
	</li>
<?php }?> 
<?php
//blog：导航
function blog_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<ul class="navbar-nav main-menu ml-4 mr-auto">
	<?php
	foreach($navi_cache as $value):

        if ($value['pid'] != 0) {
            continue;
        }

		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<li id="menu-item" class="menu-item"><a href="<?php echo BLOG_URL; ?>admin/" aria-current="page">管理站点</a></li>
			<li id="menu-item" class="menu-item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout" aria-current="page">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>
		<li id="menu-item" class="menu-item <?php echo $current_tab;?> <?php if(!empty($value['children'])){echo 'menu-item-has-children';}?>">
		<?php if(!empty($value['children'])):?>
			<span class="icon-sub-menu"><i class="iconfont icon-arrow-down-s-line"></i></span>
		<?php endif;?>
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
			<?php if (!empty($value['children'])) :?>
            <ul class="sub-menu">
                <?php foreach ($value['children'] as $row){
                        echo '<li id="menu-item" class="menu-item"><a href="'.Url::sort($row['sid']).'">'.$row['sortname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>

            <?php if (!empty($value['childnavi'])) :?>
            <ul class="sub-menu">
                <?php foreach ($value['childnavi'] as $row){
                        $newtab = $row['newtab'] == 'y' ? 'target="_blank"' : '';
                        echo '<li id="menu-item" class="menu-item"><a href="' . $row['url'] . "\" $newtab >" . $row['naviname'].'</a></li>';
                }?>
			</ul>
            <?php endif;?>

		</li>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//blog：导航
function mobile_navi(){
	global $CACHE; 
	$navi_cache = $CACHE->readCache('navi');
	?>
	<ul class="mobile-sidebar-menu nav flex-column">
	<?php
	foreach($navi_cache as $value):

        if ($value['pid'] != 0) {
            continue;
        }

		if($value['url'] == ROLE_ADMIN && (ROLE == ROLE_ADMIN || ROLE == ROLE_WRITER)):
			?>
			<li id="menu-item" class="menu-item"><a href="<?php echo BLOG_URL; ?>admin/" aria-current="page">管理站点</a></li>
			<li id="menu-item" class="menu-item"><a href="<?php echo BLOG_URL; ?>admin/?action=logout" aria-current="page">退出</a></li>
			<?php 
			continue;
		endif;
		$newtab = $value['newtab'] == 'y' ? 'target="_blank"' : '';
        $value['url'] = $value['isdefault'] == 'y' ? BLOG_URL . $value['url'] : trim($value['url'], '/');
        $current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == $value['url'] ? 'current' : 'common';
		?>
		<li id="menu-item" class="menu-item <?php echo $current_tab;?>">
			<a href="<?php echo $value['url']; ?>" <?php echo $newtab;?>><?php echo $value['naviname']; ?></a>
		</li>
	<?php endforeach; ?>
	</ul>
<?php }?>
<?php
//ajax NAV SORT
function ajax_nav_sort(){
$db = Database::getInstance();
$sql = "SELECT * FROM ".DB_PREFIX."sort WHERE pid='0' ORDER BY `sid` ASC";
$sort = $db->query($sql);?>
<li><button data-cid="home" class="btn btn-sm <?php if("http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'] == BLOG_URL){echo 'btn-primary current';}else{echo 'btn-link';}?>">推荐</button></li>
<?php
while($row = $db->fetch_array($sort)){
$current_tab = BLOG_URL . trim(Dispatcher::setPath(), '/') == Url::sort($row['sid']) ? 'btn-primary current' : 'btn-link';
?>
<li><button class="btn btn-sm <?php echo $current_tab;?>" data-cid="<?php echo $row['sid'];?>"><?php echo $row['sortname'];?></button></li>
<?php }}?>

<?php
//blog：置顶
function topflg($top, $sortop='n', $sortid=null){
    if(blog_tool_ishome()) {
       echo $top == 'y' ? "<span class=\"badge badge-hot\">推荐</span>" : '';
    } elseif($sortid){
       echo $sortop == 'y' ? "<span class=\"badge badge-hot\">推荐</span> " : '';
    }
}
?>
<?php
//blog：编辑
function editflg($logid,$author){
	$editflg = ROLE == ROLE_ADMIN || $author == UID ? '<a href="'.BLOG_URL.'admin/write_log.php?action=edit&gid='.$logid.'" target="_blank">编辑</a>' : '';
	echo $editflg;
}
?>
<?php
//blog：分类
function blog_sort($blogid){
	global $CACHE; 
	$log_cache_sort = $CACHE->readCache('logsort');
	?>
	<?php if(!empty($log_cache_sort[$blogid])){ ?>
	<a href="<?php echo Url::sort($log_cache_sort[$blogid]['id']); ?>" target="_blank"><?php echo $log_cache_sort[$blogid]['name']; ?></a>
	<?php }else{?>
	<a href="">未分类</a>
	<?php }?>
<?php }?>
<?php
//blog：文章标签
function blog_tag($blogid){
	global $CACHE;
	$log_cache_tags = $CACHE->readCache('logtags');
	if (!empty($log_cache_tags[$blogid])){
		foreach ($log_cache_tags[$blogid] as $value){
			$tag = "	<a href=\"".Url::tag($value['tagurl'])."\" itemprop=\"item\"><span itemprop=\"name\">".$value['tagname']."</span></a>";
		}
		echo $tag;
	}
}
?>
<?php
//blog：文章作者
function blog_author($uid){
	global $CACHE;
	$user_cache = $CACHE->readCache('user');
	$author = $user_cache[$uid]['name'];
	$mail = $user_cache[$uid]['mail'];
	$des = $user_cache[$uid]['des'];
	$photo = BLOG_URL.$user_cache[$uid]['photo']['src'];
	$title = !empty($mail) || !empty($des) ? "title=\"$des $mail\"" : '';

	// var_dump($photo);
	echo '
	<div class="d-none d-md-inline-block">
		<a href="'.Url::author($uid).'" target="_blank" class="flex-avatar w-20 ">
	<img alt="'.$author.'" src="'.$photo.'&amp;r=g" class="avatar avatar-20 photo w-20 loaded" height="20" width="20" data-src="'.$photo.'&amp;r=g" data-nclazyload="true" data-srcset="'.$photo.'" srcset="'.$photo.'" data-was-processed="true"></a>
	</div>
		<div class="d-inline-block ml-md-2"><a href="'.Url::author($uid).'" title="由'.$author.'发布" rel="author">'.$author.'</a></div>';

}
?>
<?php
//blog：相邻文章
function neighbor_log($neighborLog){
	extract($neighborLog);?>
	<?php if($prevLog):?>
	<div class="log-left" style="float:left"><a href="<?php echo Url::log($prevLog['gid']) ?>"><?php echo $prevLog['title'];?></a></div>
	<?php endif;?>
	<?php if($nextLog && $prevLog):?>
		|
	<?php endif;?>
	<?php if($nextLog):?>
	<div class="log-right" style="float:right"><a href="<?php echo Url::log($nextLog['gid']) ?>"><?php echo $nextLog['title'];?></a></div>
	<?php endif;?>
<?php }?>
<?php
//blog：评论列表
function blog_comments($comments){
    extract($comments);
    if($commentStacks): ?>

	<ul class="comment-list mt-3 mt-md-5">
	<?php endif; ?>
	<?php
	$isGravatar = Option::get('isgravatar');
	foreach($commentStacks as $cid):
    $comment = $comments[$cid];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
	  <li id="comment-<?php echo $comment['cid']; ?>" class="comment even thread-odd thread-alt depth-1">
	    <article id="div-comment-<?php echo $comment['cid']; ?>" class="comment-body d-flex flex-fill ">
	      <div class="comment-avatar-author vcard mr-2 mr-md-3 ">
	      <?php if($isGravatar == 'y'): ?>
	        <div class="flex-avatar w-48">
	          <img alt="" src="//gravatar.loli.net/avatar/53444f91e698c0c7caa2dbc3bdbf93fc?s=48&amp;d=<?php echo getGravatar($comment['mail']); ?>&amp;r=g" class="avatar avatar-48 photo loaded" height="48" width="48" data-src="//gravatar.loli.net/avatar/53444f91e698c0c7caa2dbc3bdbf93fc?s=48&amp;d=<?php echo getGravatar($comment['mail']); ?>&amp;r=g" data-nclazyload="true" data-srcset="//gravatar.loli.net/avatar/53444f91e698c0c7caa2dbc3bdbf93fc?s=96&amp;d=<?php echo getGravatar($comment['mail']); ?>&amp;r=g 2x" srcset="//gravatar.loli.net/avatar/53444f91e698c0c7caa2dbc3bdbf93fc?s=96&amp;d=<?php echo getGravatar($comment['mail']); ?>&amp;r=g 2x" data-was-processed="true">
	        </div>
	      <?php endif; ?>
	      </div>
	      <!-- .comment-author -->
	      <div class="comment-text d-flex flex-fill flex-column">
	        <div class="comment-info d-flex align-items-center mb-1">
	          <div class="comment-author text-sm"><?php echo $comment['poster']; ?></div></div>
	        <div class="comment-content d-inline-block text-sm">
	          <p><?php echo $comment['content']; ?></p>
	        </div>
	        <!-- .comment-content -->
	        <div class="d-flex flex-fill text-xs text-muted pt-2">
	          <div>
	            <time class="comment-date"><?php echo $comment['date']; ?></time></div>
	          <div class="flex-fill"></div>
	          <a class="comment-reply-link" onclick="return addComment.moveForm( 'comment-<?php echo $comment['cid']; ?>','<?php echo $comment['cid']; ?>', 'respond','<?php echo $logid; ?>' ) " href="?replytocom=<?php echo $comment['cid']; ?>#respond" rel="nofollow">
	            <i class="fal fa-repeat"></i>回复</a>
	        </div>
	      </div>
	      <!-- .comment-text --></article>
	    <!-- .comment-body -->

		<?php blog_comments_children($comments, $comment['children']); ?>

	    <!-- .children --></li>
	    <?php endforeach; ?>
	    <div id="pagenavi">
		    <?php echo $commentPageUrl;?>
	    </div>
	</ul>


<?php }?>
<?php
//blog：子评论列表
function blog_comments_children($comments, $children){
	$isGravatar = Option::get('isgravatar');
	foreach($children as $child):
	$comment = $comments[$child];
	$comment['poster'] = $comment['url'] ? '<a href="'.$comment['url'].'" target="_blank">'.$comment['poster'].'</a>' : $comment['poster'];
	?>
		<ul class="children">
	      <li id="comment-<?php echo $comment['cid']; ?>" class="comment odd alt depth-2">
	        <article id="div-comment-<?php echo $comment['cid']; ?>" class="comment-body d-flex flex-fill ">
	          <div class="comment-avatar-author vcard mr-2 mr-md-3 ">
	          <?php if($isGravatar == 'y'): ?>
	            <div class="flex-avatar w-48">
	              <img alt="" src="//gravatar.loli.net/avatar/eced7f048fc7f93a166d596eaf4d537e?s=48&amp;d=<?php echo getGravatar($comment['mail']); ?>&amp;r=g" class="avatar avatar-48 photo loaded" height="48" width="48" data-src="//gravatar.loli.net/avatar/eced7f048fc7f93a166d596eaf4d537e?s=48&amp;d=<?php echo getGravatar($comment['mail']); ?>&amp;r=g" data-nclazyload="true" data-srcset="//gravatar.loli.net/avatar/eced7f048fc7f93a166d596eaf4d537e?s=96&amp;d=<?php echo getGravatar($comment['mail']); ?>&amp;r=g 2x" srcset="//gravatar.loli.net/avatar/eced7f048fc7f93a166d596eaf4d537e?s=96&amp;d=<?php echo getGravatar($comment['mail']); ?>&amp;r=g 2x" data-was-processed="true">
	              </div>
	           <?php endif; ?>
	          </div>
	          <!-- .comment-author -->
	          <div class="comment-text d-flex flex-fill flex-column">
	            <div class="comment-info d-flex align-items-center mb-1">
	              <div class="comment-author text-sm"><?php echo $comment['poster']; ?></div></div>
	            <div class="comment-content d-inline-block text-sm">
	              <p><?php echo $comment['content']; ?></p></div>
	            <!-- .comment-content -->
	            <div class="d-flex flex-fill text-xs text-muted pt-2">
	              <div>
	                <time class="comment-date"><?php echo $comment['date']; ?></time></div>
	              <div class="flex-fill"></div>
	              <a class="comment-reply-link" onclick="return addComment.moveForm( 'comment-<?php echo $comment['cid']; ?>','<?php echo $comment['cid']; ?>', 'respond','<?php echo $logid; ?>' ) " href="?replytocom=<?php echo $comment['cid']; ?>#respond" rel="nofollow">
	                <i class="fal fa-repeat"></i>回复</a>
	            </div>
	          </div>
	          <!-- .comment-text --></article>
	          <?php blog_comments_children($comments, $comment['children']);?>
	        <!-- .comment-body --></li>
	        </ul>
	        <?php endforeach; ?>
	        
<?php }?>
<?php
//blog：发表评论表单
function blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark){
	if($allow_remark == 'y'): ?>
	
	<div id="respond" class="comment-respond">
	  <form method="post" action="<?php echo BLOG_URL; ?>index.php?action=addcom" id="commentform" class="comment-form  mb-4">
	  	<input type="hidden" name="gid" value="<?php echo $logid; ?>" />
	    <div class="comment-from-author">
	      <div class="comment-avatar-author d-flex flex-fill align-items-center text-sm mb-2">
	        <div class="flex-avatar w-32">
	          <img src="https://pandapro.demo.nicetheme.xyz/wp-content/themes/PandaPRO-1.0.4/images/default-avatar.png" class="avatar w-32 loaded" data-src="https://pandapro.demo.nicetheme.xyz/wp-content/themes/PandaPRO-1.0.4/images/default-avatar.png" data-nclazyload="true" data-was-processed="true"></div>
	      </div>
	      <div class="comment-form-text">
	        <div class="comment-textarea mb-3">
	          <textarea id="comment" name="comment" class="form-control form-control-sm" rows="3"></textarea>
	        </div>
	        <div class="comment-form-info row row-sm">
	        <?php if(ROLE == ROLE_VISITOR): ?>
	          <div class="col">
	            <div class="form-group comment-form-author">
	              <input class="form-control text-sm" id="author" placeholder="昵称" name="comname" type="text" value="<?php echo $ckname; ?>" required="required"></div>
	          </div>
	          <div class="col-12 col-md-4">
	            <div class="form-group comment-form-email">
	              <input id="email" class="form-control text-sm" name="commail" placeholder="Email" type="email" value="<?php echo $ckmail; ?>" required="required"></div>
	          </div>
	          <div class="col-12 col-md-4">
	            <div class="form-group comment-form-url">
	              <input class="form-control text-sm" placeholder="网站地址" id="url" name="comurl" type="url" value="<?php echo $ckurl; ?>"></div>
	          </div>
	        <?php endif; ?>
	        </div>
	        <div class="d-flex flex-fill align-items-center">
	          <!-- <div class="nice-checkbox text-muted text-xs">
	          <label for="nice-checkbox-comment">
	          <input type="checkbox" name="checkbox" id="nice-checkbox-comment" class="d-none">
	          <span class="nice-checkbox-text"></span>邮件通知我
	          </label>
	          </div> -->
	          <div class="flex-fill"></div>
	          <div class="form-submit">
	          <?php echo $verifyCode; ?>
	            <a rel="nofollow" id="cancel-comment-reply-link" style="display: none" href="javascript:;" class="btn btn-light mx-2">再想想</a>
	            <button type="submit" id="submit" class="btn btn-dark">发布评论</button>
	            <input type="hidden" name="comment_post_ID" value="4625" id="comment_post_ID">
	            <input type="hidden" name="comment_parent" id="comment_parent" value="0"></div>
	        </div>
	      </div>
	    </div>
	  </form>
	</div>

	
	<?php endif; ?>
<?php }?>
<?php
//blog-tool:判断是否是首页
function blog_tool_ishome(){
    if (BLOG_URL . trim(Dispatcher::setPath(), '/') == BLOG_URL){
        return true;
    } else {
        return FALSE;
    }
}
//格式化时间
function timeago( $ptime ) {
    $ptime = strtotime($ptime);
    $etime = time() - $ptime;
    if ($etime < 1) return '刚刚';
    $interval = array (
    12 * 30 * 24 * 60 * 60 => '年前 ('.date('Y-m-d', $ptime).')',
    30 * 24 * 60 * 60 => '个月前 ('.date('m-d', $ptime).')',
    7 * 24 * 60 * 60 => '周前 ('.date('m-d', $ptime).')',
    24 * 60 * 60 => '天前',
    60 * 60 => '小时前',
    60 => '分钟前',
    1 => '秒前'
    );
    foreach ($interval as $secs => $str) {
    $d = $etime / $secs;
    if ($d >= 1) {
    $r = round($d);
    return $r . $str;
    }
    };
}
//正则获取文章内的外链图片数量
function img_count($content){
preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $content, $imgarr);
$result = $imgarr[1];
return count($result);
}
//获取图片
function thumbnail($value){
	preg_match_all("|<img[^>]+src=\"([^>\"]+)\"?[^>]*>|is", $value['content'], $img);
	if (!empty($img[1])) {
		$thum_src = $img[1][0];
	}else{
        $thum_src = TEMPLATE_URL.'images/cover/'.rand(1,4).'-small.jpg';
    }
	echo $thum_src;
}
//分页函数
function list_page($count,$perlogs,$page,$url,$anchor=''){
$pnums = @ceil($count / $perlogs);
$page = @min($pnums,$page);
$prepg=$page-1;
$nextpg=($page==$pnums ? 0 : $page+1);
$urlHome = preg_replace("|[\?&/][^\./\?&=]*page[=/\-]|","",$url);
$re = "<nav class=\"navigation pagination\" role=\"navigation\" aria-label=\"Posts Navigation\"><h2 class=\"screen-reader-text\">Posts Navigation</h2><div class=\"nav-links\">";
if($pnums<=1) return false;

if($prepg) $re .=" <a class=\"prev page-numbers\" href=\"$url$prepg$anchor\"><span class=\"btn btn-light btn-icon btn-rounded btn-sm\"><span><i class=\"text-md iconfont icon-arrow-left-s-line\"></i></span></span></a> ";
for ($i = $page-2;$i <= $page+2 && $i <= $pnums; $i++){

if ($i > 0){if ($i == $page){$re .= " <span aria-current=\"page\" class=\"page-numbers current\">$i</span>";
}elseif($i == 1){$re .= " <a class=\"page-numbers\" href=\"$urlHome$anchor\">$i</a> ";
}else{$re .= " <a class=\"page-numbers\" href=\"$url$i$anchor\">$i</a> ";}
}}

if($nextpg) $re .=" <a class=\"next page-numbers\" href=\"$url$nextpg$anchor\"><span class=\"btn btn-light btn-icon btn-rounded btn-sm\"><span><i class=\"text-md iconfont icon-arrow-right-s-line\"></i></span></span></a>"; 
$re .="<span style=\"font-size:12px\">共 $pnums 页</span>";
$re .="</div></nav>";
return $re;}
?>
<?php
//blog：面包屑导航
function mianbao_navi($blogid,$log_title){
	global $CACHE; 
	$log_cache_navi = $CACHE->readCache('logsort');
	?>
	<div class="d-none d-md-block breadcrumbs text-muted mb-2">
      <span itemprop="itemListElement">
        <a href="<?php echo BLOG_URL; ?>" itemprop="item" class="home">
          <span itemprop="name">网站首页</span></a>
      </span>
      <span class="sep">›</span>
      <span itemprop="itemListElement">
      	<?php if(!empty($log_cache_navi[$blogid])): ?>
	    <a href="<?php echo Url::sort($log_cache_navi[$blogid]['id']); ?>" itemprop="item">
          <span itemprop="name"><?php echo $log_cache_navi[$blogid]['name']; ?></span></a>
		<?php else:?>
		未分类
		<?php endif;?>
      </span>
      <span class="sep">›</span>
      <span class="current"><?php echo $log_title; ?></span>
    </div>
<?php }?>
<?php //点赞
function syzan(){
$DB = Database::getInstance();
if($DB->num_rows($DB->query("show columns from ".DB_PREFIX."blog like 'slzan'")) == 0){
$sql = "ALTER TABLE ".DB_PREFIX."blog ADD slzan int unsigned NOT NULL DEFAULT '0'";
$DB->query($sql);}}syzan();
function update($logid){
$logid = intval($_POST['id']);
$DB = Database::getInstance();
$DB->query("UPDATE " . DB_PREFIX . "blog SET slzan=slzan+1 WHERE gid=$logid");
setcookie('slzanpd_'. $logid, 'true', time() + 31536000);}
function lemoninit() {if( @$_POST['plugin'] == 'slzanpd' &&@$_POST['action'] == 'slzan' &&isset($_POST['id'])){
$id = intval($_POST['id']);
header("Access-Control-Allow-Origin: *");
update($id);echo getnum($id);die;}}lemoninit();
function getnum($id){
static $arr = array();
$DB = Database::getInstance();
if(isset($arr[$logid])) return $arr[$logid];
$sql = "SELECT slzan FROM " . DB_PREFIX . "blog WHERE gid=$id";
$res = $DB->query($sql);
$row = $DB->fetch_array($res);
$arr[$id] = intval($row['slzan']);
return $arr[$id];}
?>