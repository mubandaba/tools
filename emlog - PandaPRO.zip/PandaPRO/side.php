<?php 
/**
 * 侧边栏
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<div class="sidebar col-lg-4 d-none d-lg-block">
<div class="theiaStickySidebar">
<?php 
$widgets = !empty($options_cache['widgets1']) ? unserialize($options_cache['widgets1']) : array();
doAction('diff_side');
foreach ($widgets as $val)
{
	$widget_title = @unserialize($options_cache['widget_title']);
	$custom_widget = @unserialize($options_cache['custom_widget']);
	if(strpos($val, 'custom_wg_') === 0)
	{
		$callback = 'widget_custom_text';
		if(function_exists($callback))
		{
			call_user_func($callback, htmlspecialchars($custom_widget[$val]['title']), $custom_widget[$val]['content']);
		}
	}else{
		$callback = 'widget_'.$val;
		if(function_exists($callback))
		{
			preg_match("/^.*\s\((.*)\)/", $widget_title[$val], $matchs);
			$wgTitle = isset($matchs[1]) ? $matchs[1] : $widget_title[$val];
			call_user_func($callback, htmlspecialchars($wgTitle));
		}
	}
}
?>
<div id="media_image-3" class="card card-sm widget widget_media_image"><a href="https://mengx.io/easter"><img width="1200" height="1029" src="https://mengx.io/content/templates/easter/img/ad.png" class="image wp-image-1764 attachment-full size-full loaded" alt="" style="max-width: 100%; height: auto;" data-src="https://mengx.io/content/templates/easter/img/ad.png" data-nclazyload="true" data-was-processed="true"></a></div>
</div>
</div><!--end #siderbar-->
