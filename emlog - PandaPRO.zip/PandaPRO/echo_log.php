<?php 
/**
 * 阅读文章页面
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
<main class="py-3 py-md-5">
  <div class="container">
  <?php mianbao_navi($logid,$log_title);?>
    
	<div class="row">
	<div class="col-lg-8">
	  <div class="post card">
	    <div class="card-body">
	      <div class="post-header border-bottom border-light mb-4 pb-4">
	        <div class="">
	          <?php blog_tag($logid); ?>
	        </div>
	        <h1 class="h3 mb-3"><?php echo $log_title; ?></h1>
	        <div class="meta d-flex align-items-center text-xs text-muted">
	          <div>
	            <time class="d-inline-block"><?php echo gmdate('Y-m-d G:i:s', $date); ?></time></div>
	          <div class="ml-auto text-sm">
	            <span class="mx-1">
	              <i class="text-md iconfont icon-eye-line mx-1"></i>
	              <small><?php echo $views;?></small></span>
	            <a class="mx-1" href="#comments">
	              <i class="text-md iconfont icon-chat--line mx-1"></i>
	              <small><?php echo $comnum;?></small></a>
	            <a data-slzanpd="<?php echo $logData['logid'];?>" class="slzanpd btn-like btn-link-like mr-md-4">
	              <i class="text-md iconfont icon-thumb-up-line mx-1"></i>
	              <small class="like-count count"><?php echo(isset($logData['slzan'])?$logData['slzan']:getnum($logData['logid']));?></small></a>
	          </div>
	        </div>
	        <div class="border-theme bg-primary"></div>
	      </div>
	      <div class="post-content">
	        <div class="nc-light-gallery">
	          <?php echo $log_content; ?>
	        </div>
	      </div>
	    </div>
	    <div class="card-footer pt-0 border-0">
	      <div id="post-share-section" class="d-flex align-items-center justify-content-between justify-content-md-start text-center text-md-left py-2">
	        <a data-slzanpd="<?php echo $logData['logid'];?>" class="slzanpd btn-like btn-link-like mr-md-4">
	          <i class="text-xl iconfont icon-thumb-up-line mx-1"></i>
	          <small class="font-theme like-count text-md counts"><?php echo(isset($logData['slzan'])?$logData['slzan']:getnum($logData['logid']));?></small></a>
	        <a href="#comments" class="mr-md-4">
	          <i class="text-xl iconfont icon-message--line"></i>
	          <small class="font-theme text-md"><?php echo $comnum;?></small></a>
	        <a href="javascript:;" class="plus-power-popup mr-md-4">
	          <i class="text-xl iconfont icon-exchange-dollar-fill"></i>
	        </a>
	        <div id="plus-power-popup-wrap">
	          <div class="popup-inner">
	            <div class="content p-4">
	              <div class="plus-power-tabcontent">
	                <div class="item-qrcode">
	                  <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" alt="苏醒" data-src="<?php echo TEMPLATE_URL; ?>images/zs.jpg" data-nclazyload="true"></div>
	              </div>
	            </div>
	          </div>
	        </div>

	        <div class="d-none d-md-flex flex-md-fill"></div>
	        <div class="content-share">
	          <a href="javascript:;" role="button" class="link-post-share mx-2">
	            <i class="text-xl iconfont icon-share-box-fill"></i>
	            <i class="text-xl iconfont icon-close-fill"></i>
	          </a>
	          <div class="nice-dropdown">
	            <div class="dropdown-inner">
	              <div class="row no-gutters">
	                <div class="col">
	                  <a href="//service.weibo.com/share/share.php?url=<?php echo Url::log($logid) ?>&amp;type=button&amp;language=zh_cn&amp;title=%E3%80%90<?php echo $log_title;?>%E3%80%91<?php echo subString(strip_tags($log_content),0,100);?>&amp;searchPic=true" target="_blank" class="item-share weibo ">
	                    <span>
	                      <i class="text-lg iconfont icon-weibo-fill"></i>
	                    </span>
	                  </a>
	                </div>
	                <div class="col">
	                  <a href="javascript:" class="item-share weixin single-popup" data-img="https://pandapro.demo.nicetheme.xyz/wp-content/themes/PandaPRO-1.0.4/modules/qrcode.php?data=<?php echo Url::log($logid) ?>" data-title="微信扫一扫 分享朋友圈" data-desc="在微信中请长按二维码">
	                    <span>
	                      <i class="text-lg iconfont icon-wechat-fill"></i>
	                    </span>
	                  </a>
	                </div>
	                <div class="col">
	                  <a href="https://connect.qq.com/widget/shareqq/index.html?url=<?php echo Url::log($logid) ?>&amp;title=<?php echo $log_title;?>&amp;summary=<?php echo subString(strip_tags($log_content),0,100);?>" target="_blank" class="item-share qq">
	                    <span>
	                      <i class="text-lg iconfont icon-qq-fill"></i>
	                    </span>
	                  </a>
	                </div>
	              </div>
	            </div>
	          </div>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div class="paid-share my-lg-4 d-none d-lg-block">
	    <a href="https://www.nicetheme.cn/store/pandapro" target="_blank">
	      <img src="https://pandapro.demo.nicetheme.xyz/wp-content/uploads/2019/07/2019072006470679.png" data-src="https://pandapro.demo.nicetheme.xyz/wp-content/uploads/2019/07/2019072006470679.png" data-nclazyload="true" class="loaded" data-was-processed="true"></a>
	  </div>
	  <div class="paid-share my-4 my-lg-0 d-lg-none">
	    <a href="https://www.nicetheme.cn/store/pandapro" target="_blank">
	      <img src="data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7" data-src="https://pandapro.demo.nicetheme.xyz/wp-content/uploads/2019/07/2019072006482096.png" data-nclazyload="true"></a>
	  </div>
	  <section class="list-related">
	    <div class="mx-1 my-3">
	      <i class="text-xl text-primary iconfont icon-refresh-line mr-2"></i>相关文章</div>
	    <div class="content-related card">
	      <div class="card-body">
	        <div class="list list-dots my-n2">
	          <?php
				$Log_Model = new Log_Model();
				$log = $Log_Model -> getLogsForHome("AND sortid =$sortid ORDER BY views ASC",0,5);
				if($log){foreach($log as $value){?>
				<div class="list-item py-2">
					<a href="<?php echo $value['log_url'];?>" target="_blank" class="list-title h-2x"><?php echo $value['log_title'];?></a>
				</div>
			  <?php }}?>
	        </div>
	      </div>
	    </div>
	  </section>
	  <div id="comments" class="comments">
	    <div class="mx-1 my-3">
	      <i class="text-xl text-primary iconfont icon-message--line mr-2"></i>评论
	      <small class="font-theme text-muted">(<?php echo $comnum;?>)</small></div>
	    <div class="card">
	      <div class="card-body">
	        <?php blog_comments_post($logid,$ckname,$ckmail,$ckurl,$verifyCode,$allow_remark); ?>
	        <?php blog_comments($comments); ?>
	        <!-- .comment-list --></div>
	    </div>
	  </div>
	  <!-- #comments --></div>


<?php
 include View::getView('side');
 include View::getView('footer');
?>