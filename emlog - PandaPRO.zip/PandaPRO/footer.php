<?php 
/**
 * 页面底部信息
 */
if(!defined('EMLOG_ROOT')) {exit('error!');} 
?>
</div></div></main>
<footer class="footer bg-dark py-3 py-lg-4">
  <div class="container">
    <div class="d-md-flex flex-md-fill align-items-md-center">
      <div class="d-md-flex flex-md-column">
        <ul class="footer-menu">
          <li id="menu-item-4888" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4888">
            <a href="https://mengx.io/class">专题</a></li>
          <li id="menu-item-4889" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4889">
            <a href="https://mengx.io/links">友情链接</a></li>
          <li id="menu-item-4890" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-4890">
            <a href="https://mengx.io/about">留言</a></li>
          <li id="menu-item-4891" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4891">
            <a href="https://mengx.io/easter">购买主题</a></li>
        </ul>
        <div class="footer-copyright text-xs">Copyright © 2020
          <a href="<?php echo BLOG_URL;?>" title="<?php echo $blogname;?>" rel="home"><?php echo $blogname;?></a>. Designed by
          <a href="https://mengx.io/" title="Mengx" target="_blank">Mengx</a>.</div></div>
      <div class="flex-md-fill"></div>
      <div class="mt-3 mt-md-0">
        <a href="javascript:" data-img="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://mengx.io/easter" data-title="Mengx BLOG" data-desc="扫一扫，立即加入我们" class="single-popup btn btn-secondary btn-qq btn-icon">
          <span>
            <i class="text-lg iconfont icon-qq-fill"></i>
          </span>
        </a>
        <a href="javascript:" data-img="https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=https://mengx.io/easter" data-title="Mengx BLOG" data-desc="微信扫一扫，立即关注" class="single-popup btn btn-secondary btn-weixin btn-icon">
          <span>
            <i class="text-lg iconfont icon-wechat-fill"></i>
          </span>
        </a>
      </div>
    </div>
    <div class="footer-links border-top border-secondary pt-3 mt-3 text-xs"><span><?php echo $footer_info; ?></span></div>
  </div>
</footer>
<a href="javascript:void(0)" id="scroll_to_top" class="btn btn-primary btn-icon scroll-to-top">
  <span>
    <i class="text-lg iconfont icon-arrow-up-fill"></i>
  </span>
</a>
<div class="mobile-overlay"></div>
<?php doAction('index_footer'); ?>
<script type="text/javascript" src="https://apollo.1.demo.nicetheme.xyz/wp-content/plugins/nicetheme-jimu/modules/jimu.js?ver=1.0"></script>
<script type="text/javascript" src="https://apollo.1.demo.nicetheme.xyz/wp-content/plugins/nicetheme-jimu/modules/base/assets/lazyload/lazyload.min.js?ver=1.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/popper.min.js?ver=1.0.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/bootstrap.min.js?ver=1.0.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/plugins.min.js?ver=1.0.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/owl.carousel.min.js?ver=1.0.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/ResizeSensor.min.js?ver=1.0.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/theia-sticky-sidebar.min.js?ver=1.0.0"></script>
<script type="text/javascript" src="<?php echo TEMPLATE_URL; ?>js/nicetheme.js?ver=1.0.2"></script>
<script type="text/javascript">
  //文章点赞
$(document).on('click', '.slzanpd',
function() {
    var a = $(this),
    id = a.data('slzanpd');
    if (slzanpd_check(id)) {
        alert('您已赞过本文！');
    } else {
        $.post('', {
            plugin: 'slzanpd',
            action: 'slzan',
            id: id
        },
        function(b) {
            a.find('u').html(b);
            slzanpd_(a);
        });
        var count = $('.count').text();
        var counts = $('.count').text();
        $('.count').text(Number(count)+1);
        $('.counts').text(Number(count)+1);
        $('.counts').addClass('current');
        $('.counts').attr('data-action', 'unlike');
    }
});
function slzanpd_check(id) {
    return new RegExp('slzanpd_' + id + '=true').test(document.cookie);
}
$('[data-slzanpd]').each(function() {
    var a = $(this),
    id = a.data('slzanpd');
    if (slzanpd_check(id)) {
        slzanpd_(a);
    } else {
        a.attr('title', '给小站来点动力吧！')
    }
});
function slzanpd_(a) {
    a.css('cursor', 'not-allowed').attr('title', '您已赞过本文！');
}
</script>
</body>
</html>